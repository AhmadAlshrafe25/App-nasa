{
  "metadata": {
    "project": "SpaceHealth - Astronaut Health & Well-being Platform",
    "scientific_framework": "NASA Human Research Program (HRP) - 5 Hazards of Human Spaceflight (RIDGE)",
    "primary_sources": [
      "NASA HRP: Five Hazards of Human Spaceflight (nasa.gov/stem-content/five-hazards-of-human-spaceflight/)",
      "NASA HRP: Risks of Human Spaceflight (nasa.gov/hrp/risks/)",
      "NASA Technical Standards: NASA-STD-3001 (Crew Health & Human Factors)",
      "Canadian Space Agency (CSA): Monitoring Radiation for Astronaut Health"
    ]
  },
  "five_hazards_knowledge_base": [
    {
      "id": "HAZARD_01",
      "name": "Space Radiation",
      "nasa_summary": "Invisible, unfeelable radiation outside Earth's protective magnetic field. Comes from three main sources: Van Allen Radiation Belts, Solar Storms (protons), and Galactic Cosmic Radiation (GCR) from supernovae—the primary concern for Mars missions.",
      "health_risks": [
        "Radiation-induced cancers",
        "Central nervous system (CNS) damage",
        "Degenerative tissue diseases",
        "Acute radiation sickness during solar particle events"
      ],
      "app_monitored_metrics": ["radiation_dosimetry_msv", "solar_flux_alert"],
      "nasa_mitigation_and_app_action": "Tracked via operational and personal dosimeters. App triggers high-priority shield alerts and calming Space Companion voice notes during solar storm spikes."
    },
    {
      "id": "HAZARD_02",
      "name": "Isolation and Confinement",
      "nasa_summary": "Behavioral issues among small groups crammed in confined spaces for months or years are inevitable. Chronic sleep loss, heavy workloads, and disrupted circadian rhythms severely impact mood and team cohesion.",
      "health_risks": [
        "Behavioral changes and psychiatric disorders",
        "Chronic sleep loss and circadian misalignment",
        "Depression, anxiety, and homesickness",
        "Inadequate teamwork and interpersonal tension"
      ],
      "app_monitored_metrics": ["sleep_hours", "sleep_quality", "stress_index", "mood_score"],
      "nasa_mitigation_and_app_action": "NASA uses light therapy and psychological support. App directly addresses this via the 'Space Companion' module—automatically playing personalized voice messages from family/loved ones when poor sleep or high stress is detected."
    },
    {
      "id": "HAZARD_03",
      "name": "Distance from Earth",
      "nasa_summary": "Mars is on average 140 million miles from Earth, causing up to a 20-minute one-way communication delay. Crews cannot rely on real-time Mission Control support or emergency resupply/evacuation.",
      "health_risks": [
        "Delayed medical diagnosis and emergency intervention",
        "Psychological disconnection from family and Earth",
        "Compromised autonomous decision-making under stress"
      ],
      "app_monitored_metrics": ["comm_delay_minutes", "offline_ai_autonomy_status"],
      "nasa_mitigation_and_app_action": "Requires complete crew and vehicle autonomy. App operates 100% locally/autonomously on-board with pre-cached family voice messages (Space Companion) so astronauts feel connected despite the 20-minute comm lag."
    },
    {
      "id": "HAZARD_04",
      "name": "Gravity Fields (Altered Gravity)",
      "nasa_summary": "Crews transition through three gravity fields on a Mars mission: weightlessness (0g) during transit, one-third Earth gravity (0.38g) on Mars, and readaptation to 1g upon return.",
      "health_risks": [
        "Spaceflight-Induced Bone Change (osteoporosis-like bone density loss)",
        "Muscle atrophy and cardiovascular deconditioning",
        "Spaceflight Associated Neuro-ocular Syndrome (SANS - vision/brain fluid shifts)",
        "Sensorimotor and balance disruption"
      ],
      "app_monitored_metrics": ["heart_rate_bpm", "blood_pressure", "daily_exercise_compliance"],
      "nasa_mitigation_and_app_action": "NASA mandates strict exercise prescriptions and fluid monitoring. App tracks resting/active heart rate anomalies and cardiovascular trends."
    },
    {
      "id": "HAZARD_05",
      "name": "Hostile/Closed Environments",
      "nasa_summary": "The spacecraft is both a home and a machine. Lack of natural air/water recycling means elevated CO2, altered microbiomes, noise, and toxic lunar/Martian dust pose constant threats.",
      "health_risks": [
        "Elevated CO2 toxicity (headaches, cognitive impairment)",
        "Host-microorganism interactions (immune system alterations, latent virus reactivation)",
        "Hypoxia during EVA/spacewalk decompression transitions",
        "Respiratory/ocular harm from space dust"
      ],
      "app_monitored_metrics": ["spo2_percent", "cabin_co2_ppm", "immune_stress_flag"],
      "nasa_mitigation_and_app_action": "ECLSS (Environmental Control and Life Support Systems) monitoring. App correlates drops in SpO2 (blood oxygen) and high cabin CO2 with heart rate spikes to trigger immediate AI Risk Alerts."
    }
  ],
  "ai_detection_thresholds": {
    "normal": {
      "heart_rate_bpm": { "min": 60, "max": 80 },
      "spo2_percent": { "min": 97.0, "max": 100.0 },
      "sleep_hours": { "min": 7.0, "max": 8.5 },
      "stress_level_1_to_10": { "min": 1, "max": 4 },
      "radiation_msv_day": { "min": 0.0, "max": 0.6 },
      "cabin_co2_ppm": { "min": 400, "max": 1000 },
      "system_action": "Maintain routine logging; no intervention needed."
    },
    "warning": {
      "heart_rate_bpm": { "min": 81, "max": 95 },
      "spo2_percent": { "min": 94.0, "max": 96.9 },
      "sleep_hours": { "min": 5.0, "max": 6.9 },
      "stress_level_1_to_10": { "min": 5, "max": 7 },
      "radiation_msv_day": { "min": 0.61, "max": 1.2 },
      "cabin_co2_ppm": { "min": 1001, "max": 2000 },
      "system_action": "Trigger yellow alert; Space Companion suggests a warm daily check-in voice note from family."
    },
    "danger_anomaly": {
      "heart_rate_bpm": { "min": 96, "max": 200 },
      "spo2_percent": { "min": 0.0, "max": 93.9 },
      "sleep_hours": { "min": 0.0, "max": 4.9 },
      "stress_level_1_to_10": { "min": 8, "max": 10 },
      "radiation_msv_day": { "min": 1.21, "max": 50.0 },
      "cabin_co2_ppm": { "min": 2001, "max": 10000 },
      "system_action": "Trigger red AI Risk Alert; check life support/shielding; Space Companion auto-queues calming family support audio."
    }
  },
  "database_seed_records": [
    {
      "mission_day": 140,
      "astronaut_name": "Commander Sarah Vance",
      "comm_delay_earth_min": 14,
      "vitals": {
        "heart_rate_bpm": 68,
        "spo2_percent": 98.5,
        "sleep_hours": 7.6,
        "sleep_quality": "Restful",
        "stress_level": 2
      },
      "environment_and_hazards": {
        "radiation_msv": 0.48,
        "radiation_source": "Baseline Galactic Cosmic Radiation (GCR)",
        "gravity_phase": "0g Transit to Mars",
        "cabin_co2_ppm": 650
      },
      "ai_assessment": {
        "status": "Normal",
        "primary_hazard_flag": "None",
        "anomaly_detected": false
      },
      "space_companion_trigger": {
        "triggered": false,
        "recommended_message": null
      }
    },
    {
      "mission_day": 141,
      "astronaut_name": "Commander Sarah Vance",
      "comm_delay_earth_min": 15,
      "vitals": {
        "heart_rate_bpm": 86,
        "spo2_percent": 96.4,
        "sleep_hours": 5.5,
        "sleep_quality": "Restless",
        "stress_level": 6
      },
      "environment_and_hazards": {
        "radiation_msv": 0.85,
        "radiation_source": "Elevated Solar Proton Activity",
        "gravity_phase": "0g Transit to Mars",
        "cabin_co2_ppm": 1250
      },
      "ai_assessment": {
        "status": "Warning",
        "primary_hazard_flag": "Isolation and Confinement / Hostile Environment",
        "anomaly_detected": true
      },
      "space_companion_trigger": {
        "triggered": true,
        "recommended_message": {
          "sender": "Mom",
          "relationship": "Mother",
          "mood_target": "Restless Sleep & Distance Stress",
          "transcript": "Good morning sweetheart. Even though we are millions of miles apart, we look up at the stars every night thinking of you. Take it one step at a time today."
        }
      }
    },
    {
      "mission_day": 142,
      "astronaut_name": "Commander Sarah Vance",
      "comm_delay_earth_min": 16,
      "vitals": {
        "heart_rate_bpm": 108,
        "spo2_percent": 93.2,
        "sleep_hours": 4.0,
        "sleep_quality": "Rough",
        "stress_level": 9
      },
      "environment_and_hazards": {
        "radiation_msv": 1.75,
        "radiation_source": "Solar Storm Spike + GCR",
        "gravity_phase": "0g Transit to Mars",
        "cabin_co2_ppm": 2150
      },
      "ai_assessment": {
        "status": "Danger",
        "primary_hazard_flag": "Space Radiation & Acute Psychological Stress",
        "anomaly_detected": true
      },
      "space_companion_trigger": {
        "triggered": true,
        "recommended_message": {
          "sender": "Dad & Little Sister",
          "relationship": "Family",
          "mood_target": "High Stress / Emergency Calm",
          "transcript": "Take a slow, deep breath. You are trained for this, you are safe, and the whole family is right there in your corner. Focus on your breathing—we love you so much."
        }
      }
    }
  ]
}